import React from "react";

function AddHome() {
  return <Layout></Layout>;
}

export default AddHome;
