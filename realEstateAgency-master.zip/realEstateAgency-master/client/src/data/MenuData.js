export const menuData = [
  { title: "About", link: "/about" },
  { title: "Homes", link: "/homes" },
  { title: "Contact Us", link: "/contact" },
  // { title: "Rentals", link: "/rentals" },
];
